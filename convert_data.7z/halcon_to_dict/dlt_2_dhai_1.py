import os
import json
import cv2
import numpy as np

def dlt_2_dhai():
    f = open("G:\luqs\halcon_to_dict\dataset.dict", "r")
    img_path = r"G:\luqs\data\螺纹2021-2-26\正面\images_total"
    lines = f.readlines()
    names = []
    for idx, line in enumerate(lines):
        print(idx)
        img_json = {"version": "1.0.0",
                    "flags": {},
                    "shapes": [],
                    "imagePath": '',
                    "imageData": None,
                    "imageHeight": 0,
                    "imageWidth": 0,
                    "imageLabel": "",
                    "rot": False, }


        if idx == 0:
            class_names = lines[0].split(":")[-1].replace("\n", "").split(",")
        else:
            img_name = line.split(":")[0]
            if img_name not in names:
                names.append((img_name))
            else:
                print(img_name)
            bbx_labels = line.split(":")[-1].split(";")
            Img = cv2.imdecode(np.fromfile(os.path.join(img_path, img_name), dtype=np.uint8), -1)
            file_name = img_name


            img_json['imagePath'] = file_name
            img_json["imageHeight"] = Img.shape[0]
            img_json["imageWidth"] = Img.shape[1]
            for label in bbx_labels:
                label = label.replace("\n", "")
                label = label.split(",")
                x0 = float(label[0])
                y0 = float(label[1])
                x1 = float(label[2])
                y1 = float(label[3])
                bbox = [x0,y0,x1,y1]
                img_json['shapes'].append({"label": class_names[int(label[4])],
                                           "points":[[bbox[0],bbox[1]],
                                                     [bbox[2],bbox[1]],
                                           [bbox[2],bbox[3]],
                                           [bbox[0],bbox[3]]],
                                            "group_id": None,
                                            "shape_type": "rectangle",
                                            "flags": ""}
                )

            json.dump(img_json, open("G:\luqs\data\螺纹2021-2-26\正面\images_total\jsons\luowen_zhengmian\\"+file_name+ '.json', 'w'))

if __name__ == '__main__':


    dlt_2_dhai()
    #json.dump(coco, open(json_file, 'w'))