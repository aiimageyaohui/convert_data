
import os
import shutil
file_dir = 'G:\luqs\data\wurenji\data'

name = 'class'

file_list = os.listdir(os.path.join(file_dir, 'trainval'))

for image in file_list:

    id = int(image.split(".")[0])
    if id % 100 ==0:
        if os.path.exists(os.path.join(file_dir,'val')):
            shutil.copy(os.path.join(file_dir,image), os.path.join(file_dir, 'val'))
        else:
            os.makedirs(os.path.join(file_dir,'val'))
            shutil.copy(os.path.join(file_dir, image), os.path.join(file_dir, 'val'))
    else:
        if os.path.exists(os.path.join(file_dir, 'train')):
            shutil.copy(os.path.join(file_dir, image), os.path.join(file_dir, 'train'))
        else:
            os.makedirs(os.path.join(file_dir, 'train'))
            shutil.copy(os.path.join(file_dir, image), os.path.join(file_dir, 'train'))

