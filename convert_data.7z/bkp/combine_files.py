import os
import shutil

source_path = os.path.abspath(r'G:\luqs\data\激光打印\新字体')  # 源文件夹
target_path = os.path.abspath(r'G:\luqs\data\激光打印\新字体\21_10_21')  # 目标文件夹

if not os.path.exists(target_path):  # 目标文件夹不存在就新建
    os.makedirs(target_path)

if os.path.exists(source_path):  # 源文件夹存在才执行
    # root 所指的是当前正在遍历的这个文件夹的本身的地址
    # dirs 是一个 list，内容是该文件夹中所有的目录的名字(不包括子目录)
    # files 同样是 list, 内容是该文件夹中所有的文件(不包括子目录)
    i = 0
    for root, dirs, files in os.walk(source_path):
        for file in files:
            i += 1
            src_file = os.path.join(root, file)
            target = target_path + '\\10_21_' + str(i)  + '.jpg'
            shutil.copy(src_file, target)
            print(src_file)

print('复制完成')