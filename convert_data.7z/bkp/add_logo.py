from PIL import Image
import os
from os.path import isfile, join

dirName = "G:/luqs/data/wurenji/det"
file_dir = join("G:/luqs/data/wurenji",'file_log')

#创建目录保存处理后的图片
try:
    os.mkdir(file_dir)
except FileExistsError:
    print('dir Exists ')

#获取当前目录下所有的jpeg格式文件路径
files = [f for f in os.listdir(dirName) if isfile(join(dirName, f))]


#打开logo图片文件
LOGO_FILE = 'C:/Users/luqs/Desktop/dahengimaging_1280_720.png'
logoIm = Image.open(LOGO_FILE)
logoWith,logoHeight = logoIm.size

#r,g,b,a =logoIm.split()

for i in range(0,len(files)):
    imTmp = Image.open(join(dirName,files[i]))

    #给图片的右下角添加log
    imWidth,imHeight = imTmp.size
    imTmp.paste(logoIm,(imWidth-logoWith,imHeight-logoHeight),logoIm)


    imTmp.save(os.path.join(file_dir,files[i]))