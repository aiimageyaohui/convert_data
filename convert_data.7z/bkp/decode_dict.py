# -*- coding: utf-8 -*-
# @Time    : 2020/8/31 17:23
# @Author  : AiVision_YaoHui
# @FileName: decode_dict.py
import cv2


f = open("E:\\bkp\\images\\dataset.dict","r")
img_path = "E:\\bkp\\images\\images\\"
lines = f.readlines()      #读取全部内容 ，并以列表方式返回
class_names=lines[0].split(":")[-1].replace("\n","").split(",")
print(lines)
print(class_names)
for line in lines[1:]:

    img_name = line.split(":")[0]
    print(img_name)
    bbx_labels = line.split(":")[-1].split(";")
    # print(bbx_labels)
    print(img_path+img_name)
    Img = cv2.imread(img_path+img_name)

    for bbx_label in bbx_labels:
        bbx_label = bbx_label.replace("\n","")
        bl = bbx_label.split(",")
        if(bl[-1]=="0"):
            cv2.rectangle(Img,(int(bl[0]),int(bl[1])),(int(bl[2]),int(bl[3])),(0,0,255),2)

        if(bl[-1]=="1"):
            cv2.rectangle(Img, (int(bl[0]), int(bl[1])), (int(bl[2]), int(bl[3])), (0, 255, 0), 2)
        print(bl)
    print("=====================")
    cv2.imshow("kk",Img)
    cv2.waitKey(0)





