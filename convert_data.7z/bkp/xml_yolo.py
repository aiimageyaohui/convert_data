import xml.etree.ElementTree as ET
import os
import json

# from detectron2.data.detection_utils import read_image
coco = dict()
coco['images'] = []
coco['type'] = 'instances'
coco['annotations'] = []
coco['categories'] = []

category_set = dict()
image_set = set()

category_item_id = 0
image_id = 20180000000
annotation_id = 0




def parseXmlFiles(xml_path):
    train_image = []
    test_image = []

    for f in os.listdir(xml_path):
        if not f.endswith('.xml'):
            continue
        height = 0
        width = 0
        bboxes = []

        bndbox = dict()
        size = dict()
        current_image_id = None
        current_category_id = None
        file_name = None
        size['width'] = None
        size['height'] = None
        size['depth'] = None

        xml_file = os.path.join(xml_path, f)
        print(xml_file)

        tree = ET.parse(xml_file)
        root = tree.getroot()
        if root.tag != 'annotation':
            raise Exception('pascal voc xml root element should be annotation, rather than {}'.format(root.tag))

        # elem is <folder>, <filename>, <size>, <object>
        for elem in root:
            current_parent = elem.tag
            current_sub = None
            object_name = None


            if elem.tag == 'folder':
                continue

            if elem.tag == 'filename':
                file_name = elem.text
                if file_name[0:4] == "test":
                    test_image.append(file_name)
                else:
                    train_image.append(file_name)
            elif elem.tag == "size":
                for subelem in elem:
                    if subelem.tag == "width":
                        width = float(subelem.text)
                    elif subelem.tag == "height":
                        height = float(subelem.text)
            elif elem.tag == "object":
                assert width != 0, "width == 0"
                bbox = []
                for subelem in elem:
                    if subelem.tag == "name":
                        if subelem.text == "face":
                            bbox.append(0)
                        else:
                            assert subelem.text == "face_mask"
                            bbox.append(1)

                    if subelem.tag == "bndbox":
                        assert bbox[0] == 0 or bbox[0] == 1
                        bbox.extend([2,2,2,2])
                        for axis in subelem:
                            if axis.tag == "xmin":

                                bbox[1] = float(axis.text)
                            elif axis.tag == "ymin":
                                bbox[2] = float(axis.text)
                            elif axis.tag == "xmax":
                                bbox[3] = float(axis.text)
                            elif axis.tag == "ymax":
                                bbox[4] = float(axis.text)
                        assert len(bbox) == 5

                        x = (bbox[3] + bbox[1])/2.0/width

                        y = (bbox[4] + bbox[2])/2.0/height

                        w = (bbox[3] - bbox[1])/width

                        h = (bbox[4] - bbox[2])/height


                        bboxes.append([bbox[0],x,y,w,h])

        filename = file_name.replace(".jpg", ".txt")

        str_con = ""
        for bbox in bboxes:
            for i in bbox:
                str_con = str_con + str(i) + " "
            str_con = str_con + "\n"
        with open("G:\luqs\code\PyTorch-YOLOv3\data\\face_mask\labels\\" + filename, "a") as myfile:
            myfile.write(str_con)
        myfile.close()

    str_train = ""
    for img in train_image:
        str_train = str_train + img + "\n"
    with open("G:\luqs\code\PyTorch-YOLOv3\data\\face_mask\\" + "data_train.txt", "a") as myfile:
        myfile.write(str_train)
    myfile.close()

    str_val = ""
    for img in test_image:
        str_val = str_val + img + "\n"
    with open("G:\luqs\code\PyTorch-YOLOv3\data\\face_mask\\" + "data_val.txt", "a") as myfile:
        myfile.write(str_val)
    myfile.close()


if __name__ == '__main__':
    xml_path = 'G:\luqs\code\PyTorch-YOLOv3\data\\face_mask\Annotations'

    parseXmlFiles(xml_path)
