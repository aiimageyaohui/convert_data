import cv2
import os

from os.path import isfile, join


def convert_frames_to_video(pathIn, pathOut, fps):
    frame_array = []
    files = [f for f in os.listdir(pathIn) if isfile(join(pathIn, f))]



    for i in range(len(files)):
        filename = pathIn +str(i) + ".jpg"
        # reading each files
        img = cv2.imread(filename)
        height, width, layers = img.shape
        height = int(height)
        width= int(width)
        img = cv2.resize(img, (width, height), interpolation=cv2.INTER_CUBIC)
        size = (width, height)
        print(filename)
        # inserting the frames into an image array
        frame_array.append(img)

    out = cv2.VideoWriter(pathOut, cv2.VideoWriter_fourcc('m', 'p', '4', 'v'), fps, size)

    for i in range(len(frame_array)):
        # writing to a image array
        out.write(frame_array[i])
    out.release()


def main():
    pathIn = 'C:\\Users\luqs\Desktop\\results\\'
    pathOut = 'C:\\Users\luqs\Desktop\\results\\1.mp4'
    fps = 14.0
    convert_frames_to_video(pathIn, pathOut, fps)


if __name__ == "__main__":
    main()