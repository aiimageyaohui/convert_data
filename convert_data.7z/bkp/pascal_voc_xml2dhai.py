import xml.etree.ElementTree as ET
import os
import json
#from detectron2.data.detection_utils import read_image













def addAnnoItem(object_name, bbox):
    global annotation_id
    annotation_item = dict()
    annotation_item['segmentation'] = []
    seg = []
    #bbox[] is x,y,w,h
    #left_top
    seg.append(bbox[0])
    seg.append(bbox[1])
    #left_bottom
    seg.append(bbox[0])
    seg.append(bbox[1] + bbox[3])
    #right_bottom
    seg.append(bbox[0] + bbox[2])
    seg.append(bbox[1] + bbox[3])
    #right_top
    seg.append(bbox[0] + bbox[2])
    seg.append(bbox[1])

    annotation_item['segmentation'].append(seg)

    annotation_item['area'] = bbox[2] * bbox[3]
    annotation_item['iscrowd'] = 0
    annotation_item['ignore'] = 0

    annotation_item['bbox'] = bbox

    annotation_id += 1
    annotation_item['id'] = annotation_id


def parseXmlFiles(xml_path):
    for f in os.listdir(xml_path):
        if not f.endswith('.xml'):
            continue

        img_json = {"version": "1.0.0",
                    "flags": {},
                    "shapes": [],
                    "imagePath": '',
                    "imageData": None,
                    "imageHeight": 0,
                    "imageWidth": 0,
                    "imageLabel": "",
                    "rot": False, }
        
        bndbox = dict()
        size = dict()
        current_image_id = None
        current_category_id = None
        file_name = None
        size['width'] = None
        size['height'] = None
        size['depth'] = None

        xml_file = os.path.join(xml_path, f)
        print(xml_file)

        tree = ET.parse(xml_file)
        root = tree.getroot()
        if root.tag != 'annotation':
            raise Exception('pascal voc xml root element should be annotation, rather than {}'.format(root.tag))

        #elem is <folder>, <filename>, <size>, <object>
        for elem in root:
            current_parent = elem.tag
            current_sub = None
            object_name = None
            
            if elem.tag == 'folder':
                continue
            
            if elem.tag == 'filename':
                file_name = elem.text
                img_json['imagePath'] = file_name

            if elem.tag == "size":
                for subelem in elem:
                    if subelem.tag == "height":
                        img_json["imageHeight"] = int(subelem.text)
                    if subelem.tag == "width":
                        img_json["imageWidth"] = int(subelem.text)



            for subelem in elem:
                bndbox ['xmin'] = None
                bndbox ['xmax'] = None
                bndbox ['ymin'] = None
                bndbox ['ymax'] = None
                
                current_sub = subelem.tag
                if current_parent == 'object' and subelem.tag == 'name':
                    object_name = subelem.text


                elif current_parent == 'size':
                    if size[subelem.tag] is not None:
                        raise Exception('xml structure broken at size tag.')
                    size[subelem.tag] = int(subelem.text)

                #option is <xmin>, <ymin>, <xmax>, <ymax>, when subelem is <bndbox>
                for option in subelem:
                    if current_sub == 'bndbox':
                        if bndbox[option.tag] is not None:
                            raise Exception('xml structure corrupted at bndbox tag.')
                        bndbox[option.tag] = int(option.text)

                #only after parse the <object> tag
                if bndbox['xmin'] is not None:
                    if object_name is None:
                        raise Exception('xml structure broken at bndbox tag')

                    bbox = []
                    #x
                    bbox.append(bndbox['xmin'])
                    #y
                    bbox.append(bndbox['ymin'])
                    #w
                    bbox.append(bndbox['xmax'])
                    #h
                    bbox.append(bndbox['ymax'])
                    img_json['shapes'].append({"label": object_name,
                                               "points":[[bbox[0],bbox[1]],
                                                         [bbox[2],bbox[1]],
                                               [bbox[2],bbox[3]],
                                               [bbox[0],bbox[3]]],
                                                "group_id": None,
                                                "shape_type": "rectangle",
                                                "flags": ""}
                    )

        json.dump(img_json, open("G:\luqs\data\Drone\images\jsons\drone\\"+file_name+ '.json', 'w'))

if __name__ == '__main__':
    xml_path = 'G:\luqs\data\Drone\\val_label'
    json_file = 'G:\luqs\data\Drone\\train_label.json'
    parseXmlFiles(xml_path)
    #json.dump(coco, open(json_file, 'w'))