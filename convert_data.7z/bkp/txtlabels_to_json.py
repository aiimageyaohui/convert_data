import json

def TXTLABELS_TO_JSON(srcpath, json_file):
    txtlabels = open(srcpath,encoding='utf_8_sig')
    data_dict = {}

    data_dict['images'] = []
    data_dict['categories'] = []
    data_dict['annotations'] = []
    class_ids = []
    class_names = []
    image_ids = []
    for idx, line in enumerate(txtlabels):
        if idx==0:
            line = line[10:]
            line = line.strip("\n")
            class_ids=line.split(";")
            if class_ids[-1]=="":
                class_ids.pop(-1)

        if idx==1:
            line = line[12:]
            line = line.strip("\n")
            class_names = line.split(";")
            if class_names[-1]=="":
                class_names.pop(-1)
            class_names = [i.replace("\"","") for i in class_names]

        if idx >= 5:
            line = line.strip("\n")
            anno = {}
            image = {}
            list=line.split(";")
            if list[0] not in image_ids:
                image_ids.append(list[0])
                image["id"] = list[0]
                image["file_name"] = list[1]
                image["width"] = 0
                image["height"] = 0
                data_dict['images'].append(image)
            anno["segmentation"]="none"
            anno["iscrowd"]=0
            anno["ignore"]=0

            anno["image_id"]=list[0]
            anno["category_id"]=list[2]
            anno["id"]=idx-4
            width = abs(float(list[5])-float(list[3])) + 1
            height = abs(float(list[6])-float(list[4])) + 1
            x_c = (float(list[5]) + float(list[3]))/2
            y_c = (float(list[6]) + float(list[4]))/2
            anno["bbox"] = [x_c, y_c, width, height]
            anno["area"]= width * height
            data_dict['annotations'].append(anno)




    for id, name in zip(class_ids, class_names):

        data_dict["categories"].append({"supercategory": "none", "id":id if class_ids[0]==0 else str(int(id)+1),"name":name})


    json.dump(data_dict, open(json_file, 'w'))


if __name__ == '__main__':
    TXTLABELS_TO_JSON('G:/luqs/labels.txt', json_file ='G:/luqs/labels.json' )
