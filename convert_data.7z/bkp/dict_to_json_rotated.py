# -*- coding: UTF-8 -*-
import json
import cv2
import math
import os
import numpy as np
def build_json():

    f = open("G:\luqs\halcon_to_dict\label.hdict", "r")
    img_path = r"G:\luqs\data\yaohejiance\1\image"
    lines = f.readlines()
    data_dict = {}
    data_dict['images'] = []
    data_dict['categories'] = []
    data_dict['annotations'] = []
    class_names = []
    image_ids = []
    image_idx = 0
    instance_idx = 0
    for idx, line in enumerate(lines):
        if idx == 0:
            class_names = lines[0].split(":")[-1].replace("\n", "").split(",")
        else:
            img_name = line.split(":")[0]
            bbx_labels = line.split(":")[-1].split(";")
            Img = cv2.imdecode(np.fromfile(os.path.join(img_path, img_name), dtype=np.uint8), -1)

            image = {}

            image_ids.append(image_idx)
            image["id"] = image_idx
            image["file_name"] = img_name
            image["width"] = Img.shape[1]
            image["height"] = Img.shape[0]
            data_dict['images'].append(image)


            for label in bbx_labels:

                anno = {}
                label = label.replace("\n", "")
                label = label.split(",")
                if len(label) == 6:
                    anno["segmentation"] = ""
                    anno["iscrowd"] = 0
                    anno["ignore"] = 0
                    anno["image_id"] = int(image_idx)
                    anno["category_id"] = int(label[5]) + 1

                    anno["id"] = instance_idx
                    width = float(label[2])
                    height = float(label[3])
                    x0 = float(label[0])
                    y0 = float(label[1])
                    angle = float(label[4]) * 180 / math.pi
                    #x_c = (float(label[2]) + float(label[0])) / 2
                    #y_c = (float(label[3]) + float(label[1])) / 2
                    anno["bbox"] = [x0, y0, width, height, angle]
                    anno["area"] = width * height
                    data_dict['annotations'].append(anno)
                    instance_idx += 1
            image_idx += 1


    for id, name in enumerate(class_names):

        data_dict["categories"].append({"supercategory": "none", "id":id + 1,"name":name})


    json.dump(data_dict, open("G:\luqs\halcon_to_dict\\dataset.json", 'w'))
    return image_idx

if __name__ == "__main__":
    n = build_json()
