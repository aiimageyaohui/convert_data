# -*- coding: utf-8 -*-
# @Time    : 2021/12/30 17:01
# @Author  : AiVision_YaoHui
# @FileName: write_labels.py

import sys
import os
import json
import xml.etree.ElementTree as ET
import glob



def get_categories(xml_files):
    """Generate category name to id mapping from a list of xml files.

    Arguments:
        xml_files {list} -- A list of xml file paths.

    Returns:
        dict -- category name to id mapping.
    """
    classes_names = []
    for xml_file in xml_files:
        tree = ET.parse(xml_file)
        root = tree.getroot()
        for member in root.findall("object"):
            classes_names.append(member[0].text)
    classes_names = list(set(classes_names))
    classes_names.sort()
    return {name: i for i, name in enumerate(classes_names)}


xml_dir = "G:/dataset/VOCdevkit/part/VOC2012/Annotations/"
xml_files = glob.glob(os.path.join(xml_dir, "*.xml"))
class_dict = get_categories(xml_files)
class_list = [k for k, v in class_dict.items()]
file = "labels.txt"
with open(file, "w",encoding="utf-8") as f:
    f.write('\n'.join(class_list))


print(get_categories(xml_files))